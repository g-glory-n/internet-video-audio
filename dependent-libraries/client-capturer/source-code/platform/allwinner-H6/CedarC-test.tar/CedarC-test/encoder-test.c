#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <errno.h>

#include "include/vencoder.h"
#include "include/vdecoder.h"

int main(int argc, char *argv[])
{
        VideoEncoder *VideoEncoder__point__video_encoder = NULL;
        VideoEncoder__point__video_encoder = VideoEncCreate(VENC_CODEC_H264);

        VideoEncDestroy(VideoEncoder__point__video_encoder);

        return 0;
}


