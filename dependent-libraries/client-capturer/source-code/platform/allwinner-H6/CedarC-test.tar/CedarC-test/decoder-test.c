#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <errno.h>

#include "include/vencoder.h"
#include "include/vdecoder.h"

int main(int argc, char *argv[])
{
	VideoDecoder *VideoDecoder__point__video_decoder = NULL;
	VideoDecoder__point__video_decoder = CreateVideoDecoder();

        DestroyVideoDecoder(VideoDecoder__point__video_decoder);

	return 0;
}
