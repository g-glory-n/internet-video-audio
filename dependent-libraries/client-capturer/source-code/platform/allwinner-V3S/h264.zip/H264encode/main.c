#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <sys/time.h>
#include <linux/types.h>
#include <sys/epoll.h>
#include <sys/ioctl.h>
#include <signal.h>
#include <video/vencoder.h>
#include "rgb565tobmp.h"
#include "camera.h"
#include "selector.h"
#include "thpool.h"
#include "H264_encoder.h"
#include "semaphore.h"
int flag = 1;
int frame_num = 0;
void sig_alarm()
{	
		printf("stop loog\n");
		flag = 0;
}
int main(int argc,char** argv)
{
    int i;
    int ret = 0;
    int io_num = 0;
    int io_flag = RDIO;
    FILE* fpH264 = NULL;
    struct fd_data* data = NULL;
		struct camera* camera= camera_init();
		struct selector* selector = create_init_selector(10);
		//camera->H264_encoder = H264_encoder_init(camera);
		selector_add_io(selector,GET_CAM_MEMBER(camera,fd),camera,RDIO);
		//threadpool thpool = thpool_init(4);
		//fpH264 = fopen("/tmp/dst.h264","w+");
		signal(SIGALRM, sig_alarm);
		alarm(10);
		while(frame_num != 10)
		{
	    	selector_reset_io(selector);
				io_num = selector_wait(selector,io_flag);
				memset(&GET_CAM_MEMBER(camera,buffer),0,sizeof(GET_CAM_MEMBER(camera,buffer)));//��ֹ��δ���
				camera->v4l2_device->buffer.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;//֡����
				camera->v4l2_device->buffer.memory = V4L2_MEMORY_MMAP;
				ioctl(GET_CAM_MEMBER(camera,fd), VIDIOC_DQBUF, &GET_CAM_MEMBER(camera,buffer));
				ioctl(GET_CAM_MEMBER(camera,fd), VIDIOC_QBUF, &GET_CAM_MEMBER(camera,buffer));//����
				printf("frame_num = %d\n",frame_num);
				if(io_num < 0)
	          printf("\n select failed");
	      else if(io_num == 0)
	          printf("\n timeout");
	      else
	      {
	      		data = GET_SEL_DATA(selector);
	      		if(frame_num == 8)
	      		{
		      		for(i = 0;i < io_num;i++)
		      		{
		      				if( data[i].fd ==  GET_CAM_MEMBER(camera,fd) )//�ж��Ƿ�������¼�
		      				{
		      					 cam_handler(camera);
		      				}
		      		}
	      		}
	      }
	      frame_num++;
    }
   // close_H264_encoder(camera->H264_encoder);
    //thpool_destroy(thpool);
    return 0;
}
