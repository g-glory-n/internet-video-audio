#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <linux/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <errno.h>
#include <linux/videodev2.h>
#include "camera.h"
#include "rgb565tobmp.h"
#include "H264_encoder.h"
int v4l2_palette[] = {
		V4L2_PIX_FMT_JPEG,
		V4L2_PIX_FMT_MJPEG,  
		V4L2_PIX_FMT_SPCA561, 
		V4L2_PIX_FMT_RGB24,  
		V4L2_PIX_FMT_BGR24,  
		V4L2_PIX_FMT_RGB32,  
		V4L2_PIX_FMT_BGR32,  
		V4L2_PIX_FMT_YUYV,   
		V4L2_PIX_FMT_UYVY,  
		V4L2_PIX_FMT_YUV420, 
		V4L2_PIX_FMT_SBGGR8, 
		V4L2_PIX_FMT_SGBRG8, 
		V4L2_PIX_FMT_SGRBG8, 
		V4L2_PIX_FMT_RGB565, 
		V4L2_PIX_FMT_RGB555, 
		V4L2_PIX_FMT_Y16,   
		V4L2_PIX_FMT_GREY, 
		0
};
/*IO��������*/
void cam_encode_handler(struct camera* camera,FILE* fpH264)
{
			printf("cature camera event\n");
			memset(&GET_CAM_MEMBER(camera,buffer),0,sizeof(GET_CAM_MEMBER(camera,buffer)));//��ֹ��δ���
			camera->v4l2_device->buffer.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;//֡����
			camera->v4l2_device->buffer.memory = V4L2_MEMORY_MMAP;
			ioctl(GET_CAM_MEMBER(camera,fd), VIDIOC_DQBUF, &GET_CAM_MEMBER(camera,buffer));
			H264_write_head(camera->H264_encoder,fpH264);
			H264_encode_handle(camera->H264_encoder,fpH264,GET_CAM_MEMBER(camera,buffer).index);//���벢д��
			ioctl(GET_CAM_MEMBER(camera,fd), VIDIOC_QBUF, &GET_CAM_MEMBER(camera,buffer));//����
}
void cam_handler(void *arg)
{
     struct camera *camera = arg;
     int file_fd = 0;
		 memset(&GET_CAM_MEMBER(camera,buffer),0,sizeof(GET_CAM_MEMBER(camera,buffer)));//��ֹ��δ���
     camera->v4l2_device->buffer.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
     camera->v4l2_device->buffer.memory = V4L2_MEMORY_MMAP;
     
     /*buf ����*/
     ioctl (GET_CAM_MEMBER(camera,fd), VIDIOC_DQBUF, &GET_CAM_MEMBER(camera,buffer));
     file_fd = open("image-dump",O_RDWR|O_CREAT,0777);
		 write(file_fd,GET_CAM_MEMBER(camera,image_buf_info)->start_addr,GET_CAM_MEMBER(camera,image_buf_info)->length);
		 
     /*buf����*/
     //ioctl(GET_CAM_MEMBER(camera,fd), VIDIOC_QBUF, &GET_CAM_MEMBER(camera,buffer));	
}
void cam_handler_tobmp(struct camera* camera)
{
     camera->v4l2_device->buffer.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
     camera->v4l2_device->buffer.memory = V4L2_MEMORY_MMAP;
     
     /*buf ����*/
     ioctl (GET_CAM_MEMBER(camera,fd), VIDIOC_DQBUF, &GET_CAM_MEMBER(camera,buffer));
     
		 Rgb565ConvertBmp(GET_CAM_MEMBER(camera,image_buf_info)[GET_CAM_MEMBER(camera,buffer).index].start_addr,640,480,"my.bmp");
		 
     /*buf����*/
     ioctl(GET_CAM_MEMBER(camera,fd), VIDIOC_QBUF, &GET_CAM_MEMBER(camera,buffer));	
}
void* get_image_start_addr(struct camera *camera)
{
	   return camera->v4l2_device;
}
struct v4l2_device * v4l2_init()
{

     struct v4l2_device *v4l2_device;
     int i;
		 int ioctl_ret = 0;
     //1. ��ʼ������ͷ
     v4l2_device = calloc(1,sizeof(struct v4l2_device));
     v4l2_device->fd = open("/dev/video0",O_RDWR|O_NONBLOCK);
     
     //1.1 ��������ͷ����
     memset (&v4l2_device->input, 0, sizeof (v4l2_device->input));
     v4l2_device->input.index = 0; //Ĭ������Ϊ0,���Ը��������������Ӷ�̬���Ĵ���
     DEBUG("input.index = %d\n",v4l2_device->input.index);
     ioctl_ret = ioctl (v4l2_device->fd, VIDIOC_S_INPUT, &v4l2_device->input.index);
     DEBUG("ioctl_ret = %d\n",ioctl_ret);
  
     
     //1.2 ��ȡ������Ϣ
     ioctl (v4l2_device->fd, VIDIOC_QUERYCAP, &v4l2_device->capability);
     
     if (!(v4l2_device->capability.capabilities & V4L2_CAP_VIDEO_CAPTURE))
     {
          printf("this is not a video device\n");
          return NULL;	
     }
     strcpy((char *)v4l2_device->device_name,(char *)v4l2_device->capability.card);
     strcpy((char *)v4l2_device->driver_name,(char *)v4l2_device->capability.driver);
     DEBUG("cap.card is %s\n",(char *)v4l2_device->capability.card);
     DEBUG("cap.driver is %s\n",(char *)v4l2_device->capability.driver);
     
     
     //1.3 ����ͼ���ʽ
     
     printf("enter your width \n");  
     scanf("%d",&v4l2_device->resolution.Width);
     printf("enter your heigth \n");  
     scanf("%d",&v4l2_device->resolution.Height);
     
     //v4l2_device->resolution.Width = 640;
     //v4l2_device->resolution.Height = 480;
     v4l2_device->format.type                = V4L2_BUF_TYPE_VIDEO_CAPTURE;
     v4l2_device->format.fmt.pix.width       = v4l2_device->resolution.Width;
     v4l2_device->format.fmt.pix.height      = v4l2_device->resolution.Height;
     v4l2_device->format.fmt.pix.field       = V4L2_FIELD_ANY;
     //v4l2_device->format.fmt.pix.pixelformat = V4L2_PIX_FMT_UYVY; 
     //v4l2_device->format.fmt.pix.pixelformat = V4L2_PIX_FMT_RGB565;
     v4l2_device->format.fmt.pix.pixelformat = V4L2_PIX_FMT_SGRBG12;
     if(ioctl(v4l2_device->fd, VIDIOC_S_FMT, &v4l2_device->format) == -1)
     {
     	    printf("VIDIOC_S_FMT: %s", strerror(errno));
     	    return NULL;
     }
     
		 DEBUG("format is %c%c%c%c \n",v4l2_device->format.fmt.pix.pixelformat >> 0, v4l2_device->format.fmt.pix.pixelformat >> 8,
		 															 v4l2_device->format.fmt.pix.pixelformat >> 16, v4l2_device->format.fmt.pix.pixelformat >> 24);
		 															 
		 															 
     //1.4 ����ͼ�񻺳���
     v4l2_device->buffer_num = 4;
     v4l2_device->requestbuffers.count = v4l2_device->buffer_num;
     v4l2_device->requestbuffers.type   = V4L2_BUF_TYPE_VIDEO_CAPTURE;
     v4l2_device->requestbuffers.memory  = V4L2_MEMORY_MMAP;
     ioctl (v4l2_device->fd, VIDIOC_REQBUFS, &v4l2_device->requestbuffers);
     DEBUG("finished request buffers\n");

     v4l2_device->image_buf_info = calloc(4,sizeof(struct image_buf_info));
     
     /*��ȡͼ�񻺳�������Ϣ*/
     for (i = 0; i < v4l2_device->requestbuffers.count; i++)
     { 
           v4l2_device->buffer.type  = V4L2_BUF_TYPE_VIDEO_CAPTURE;
           v4l2_device->buffer.memory  = V4L2_MEMORY_MMAP;
           v4l2_device->buffer.index  = i;
 
           ioctl (v4l2_device->fd, VIDIOC_QUERYBUF, &v4l2_device->buffer); 
           
           v4l2_device->image_buf_info[i].length = v4l2_device->buffer.length; 
           DEBUG("buf.length = %d\n", v4l2_device->buffer.length);
           // ���ں˿ռ��е�ͼ�񻺳���ӳ�䵽�û��ռ�
           v4l2_device->image_buf_info[i].start_addr = mmap (NULL ,    //ͨ��mmap����ӳ���ϵ
					                                        v4l2_device->buffer.length,
					                                        PROT_READ | PROT_WRITE ,
					                                        MAP_SHARED ,
					                                        v4l2_device->fd,
					                                        v4l2_device->buffer.m.offset);
						v4l2_device->image_buf_info[i].addrVirY = v4l2_device->image_buf_info[i].start_addr;
						v4l2_device->image_buf_info[i].addrVirC = v4l2_device->image_buf_info[i].addrVirY +
																										  ALIGN_16B(v4l2_device->resolution.Width) *
																										  ALIGN_16B(v4l2_device->resolution.Height);
     }
     DEBUG("finished mmap buffers\n");
     //1.5 ͼ�񻺳����
     for (i = 0; i < 4; ++i)
       {
               v4l2_device->buffer.type        = V4L2_BUF_TYPE_VIDEO_CAPTURE;
               v4l2_device->buffer.memory      = V4L2_MEMORY_MMAP;
               v4l2_device->buffer.index       = i; 
               ioctl_ret = ioctl (v4l2_device->fd, VIDIOC_QBUF, &v4l2_device->buffer);
               DEBUG("ioctl_ret = %d\n",ioctl_ret);
               if(ioctl_ret == -1)
               	{
               			printf("queue buffer failed!\n");
               			printf("VIDIOC_QBUF: %s", strerror(errno));
               	}     
       }
     
     DEBUG("finished queue buffers\n");
     if(ioctl (v4l2_device->fd, VIDIOC_G_FMT, &v4l2_device->format) == -1)
     {
     	    printf("VIDIOC_S_FMT: %s", strerror(errno));
     	    return NULL;
     }
     DEBUG("fmt->fmt.pix.pixelformat = %x\n",v4l2_device->format.fmt.pix.pixelformat);
     return v4l2_device;
	
}

void camera_start_capture(struct camera *camera)
{
    enum v4l2_buf_type type;
    DEBUG("enter v4l2_start_capture\n");
    type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    ioctl (camera->v4l2_device->fd, VIDIOC_STREAMON, &type);
}

struct camera * camera_init()
{
     struct camera *camera= calloc(1,sizeof(struct camera));
     
     //1. ��ʼ��
     camera->v4l2_device = v4l2_init();
     camera->cam_handler = cam_handler;
     camera->arg = camera;
     DEBUG("finished v4l2 init\n");
     //2. ��ʼ�ɼ�
     camera_start_capture(camera);
     return camera;
     	
}