#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <stdlib.h>
#include <unistd.h>
#include "semaphore.h"

//�����źż�������
int set_sem_num(struct semaphore* semaphore,int num)
{
		if(NULL == semaphore)
		{
				printf("[%s] Error,semaphore == NULL\n",__FUNCTION__);
				return 0;;
		}
	  semaphore->sem_union.val  = num * 5 ;
		if(-1 == semctl(semaphore->semid,0,SETVAL,semaphore->sem_union.val))
		{
				printf("[%s] Error,semctl SETVAL failed\n",__FUNCTION__);
		    return -1;
		}
		return 1;
}

//�����ź���
struct semaphore* semaphore_init(int semaphore_num,char* name)
{
			int ret = 0;
			struct semaphore* semaphore = (struct semaphore*)malloc(sizeof(struct semaphore));
			semaphore->semaphore_num = semaphore_num;
			semaphore->ftok_key = ftok(name,getpid());//�����ź���Key
			semaphore->semid = semget(semaphore->ftok_key,1,IPC_CREAT);//�����ź���
			ret = set_sem_num(semaphore,semaphore_num);//�����ź�����
			if( 0 == ret || -1 == ret)
			{
					printf("[%s] Error,set_sem_num failed\n",__FUNCTION__);
					return NULL;
			}
			return semaphore;
}

//ɾ���źż�
int del_semvalue(struct semaphore* semaphore)
{
	 	if(NULL == semaphore)
		{
				printf("[%s] Error,semaphore == NULL\n",__FUNCTION__);
				return 0;
		}
		if(-1 == semctl(semaphore->semid,0,IPC_RMID,semaphore->sem_union))
		{
			printf("[%s] Error,semctl IPC_RMID failed\n",__FUNCTION__);
			return -1;
		}
		free(semaphore);
		return 1;
}

//�ź���P����
int semaphore_p_op(struct semaphore* semaphore)
{
	if(NULL == semaphore)
	{
			printf("[%s] Error,semaphore == NULL\n",__FUNCTION__);
			return 0;
	}
	semaphore->sembuf.sem_num = 0;//�ź������
	semaphore->sembuf.sem_op = -5;//P����	
	semaphore->sembuf.sem_flg = SEM_UNDO;
	if(semop(semaphore->semid,&semaphore->sembuf,1) == -1)
	{
		  printf("[%s] Error 	 failed\n",__FUNCTION__); 
	    return 0;
	}
	return 1;
}


//�ź���V����
int semaphore_v_op(struct semaphore* semaphore)//�ź���V���� +1
{
	if(NULL == semaphore)
	{
			printf("[%s] Error,semaphore == NULL\n",__FUNCTION__);
			return 0;
	}
	semaphore->sembuf.sem_num = 0;//�ź������
	semaphore->sembuf.sem_op = 5;//V����	
	semaphore->sembuf.sem_flg = SEM_UNDO;
	if(semop(semaphore->semid,&semaphore->sembuf,1) == -1)
	{
	    printf("[%s] Error semop failed\n",__FUNCTION__);
	    return 0;
	}

	return 1;
}
