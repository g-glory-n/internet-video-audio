#!/bin/bash
clear
make clean
make
chmod 777 demo
