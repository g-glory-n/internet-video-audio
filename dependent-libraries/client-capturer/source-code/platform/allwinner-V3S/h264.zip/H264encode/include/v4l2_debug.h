#ifndef _V4L2_DEBUG_H
#define _V4L2_DEBUG_H
#define DEBUG_EN 1
#define DEBUG(x,arg...) if(DEBUG_EN) printf("[V4L2APP_DEBUG]"x,##arg)
#endif