#ifndef _CAMERA_H_
#define _CAMERA_H_
#include <linux/videodev2.h>
#include "v4l2_debug.h"
#define GET_CAM_MEMBER(cam,member) cam->v4l2_device->member
struct resolution
{
		int Width;
		int Height;
};
struct image_buf_info
{
    void *start_addr;
    int length;	
    char *addrVirY;
	  char *addrVirC;
};
struct v4l2_device
{
    int fd;
    int buffer_num;
    __u8 device_name[32];
    __u8 driver_name[16];
     struct v4l2_capability capability;//V4L2 ����
     struct v4l2_format format;//��ʽ
     struct v4l2_requestbuffers requestbuffers;//����֡
     struct v4l2_buffer buffer;  //ͼ�񻺳�
     struct v4l2_input input;//ʶ�����������
     struct v4l2_fmtdesc fmtdesc;//�豸��ʽ��Ϣ
     struct image_buf_info *image_buf_info;//ͼ�񻺳���Ϣ
     struct resolution resolution;
};
struct camera 
{
    struct v4l2_device *v4l2_device;
    void (*cam_handler)(void*);
    void* arg;
    struct H264_encoder* H264_encoder;
};
void cam_encode_handler(struct camera* camera,FILE* fpH264);
struct camera * camera_init();
void cam_handler(void *arg);
struct v4l2_device * v4l2_init();
void camera_start_capture(struct camera *camera);
void* get_image_buf_info(struct camera *camera);
void* get_buffer(struct camera *camera);
void cam_handler_tobmp(struct camera* camera);
#endif