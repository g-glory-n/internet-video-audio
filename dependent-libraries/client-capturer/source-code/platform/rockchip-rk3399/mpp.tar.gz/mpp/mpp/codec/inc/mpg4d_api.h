#ifndef __MPG4D_API_H__
#define __MPG4D_API_H__

#include "parser_api.h"

#ifdef  __cplusplus
extern "C" {
#endif

extern const ParserApi api_mpg4d_parser;

#ifdef  __cplusplus
}
#endif

#endif

